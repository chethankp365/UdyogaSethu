<div align="center">

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-banner.svg" alt="UdyogaSethu banner: a boy pops out of the D and holds a phone out of the O, with a bridge under SETHU connecting farm and city" width="100%"/>

<br/>

**A voice-first bridge between informal work and farm markets.**
Find a job, book a service, sell produce or buy it direct, all with one account, in your own language.

<br/>

![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![Supabase](https://img.shields.io/badge/Supabase-065F46?style=for-the-badge&logo=supabase&logoColor=3ECF8E)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL%20%2B%20PostGIS-1E4F8F?style=for-the-badge&logo=postgresql&logoColor=white)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot%20%2B%20Vaadin-2E7D32?style=for-the-badge&logo=springboot&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase%20FCM-C2570C?style=for-the-badge&logo=firebase&logoColor=white)

![Status](https://img.shields.io/badge/status-research%20prototype-FF8A1F?style=flat-square)
![Payments](https://img.shields.io/badge/payments-sandbox-3B82F6?style=flat-square)
![Voice](https://img.shields.io/badge/voice-8%20languages-10B981?style=flat-square)
![Tests](https://img.shields.io/badge/functional%20tests-47%2F50-10B981?style=flat-square)

[App tour](#-app-tour) · [Features](#-what-it-does) · [Job workflow](#-how-a-job-moves-from-post-to-paid) · [Voice](#-voice-assistant) · [Architecture](#-architecture) · [Security](#-security-hardening) · [Results](#-measured-results) · [Run it](#-getting-started)

</div>

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🌉 Why this exists

*Udyoga* means work. *Sethu* means bridge.

India's electricians, plumbers, drivers, domestic workers and small farmers keep local economies running, yet they still find customers through word of mouth and middlemen. Job portals, service-booking apps and farm marketplaces exist, but they sit apart, so a worker who also farms ends up with two accounts, two verifications and two payment flows.

UdyogaSethu puts both marketplaces on **one identity, one verification and one payment system**, and lets people drive it by speaking.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-ecosystem.svg" width="100%" alt="UdyogaSethu ecosystem: a local service marketplace and a farmer-to-customer marketplace joined by one account"/>

| The problem | How UdyogaSethu answers it |
|---|---|
| Hard to find nearby, trustworthy work | Location-based discovery on a live map (PostGIS distance search) |
| Middlemen take the margin on produce | Farmers list directly and customers order direct |
| English-only apps exclude many users | Multilingual UI and a voice assistant in eight languages |
| Strangers have no way to trust each other | Verified identity, QR + selfie + GPS attendance, ratings, evidence-based disputes |
| Worry about payment safety | Server-verified payments and a transaction record both sides can see |
| Separate apps for work and farm sales | One account across both marketplaces |

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 📱 App tour

Nine real screens from the running Flutter app, across three roles. The tour below plays on its own (demonstration data, not real transactions).

<div align="center">

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-app-tour-animated.svg" width="100%" alt="Animated app tour cycling through nine UdyogaSethu screens for workers, farmers and customers"/>

</div>

<details>
<summary><b>Prefer a still gallery? Open all nine screens</b></summary>

<br/>

<div align="center">

**Workers: find it, book it, show up**

<table>
<tr>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-worker-home.jpg" width="230" alt="Worker home"/><br/><sub><b>Home</b><br/>daily goal, wallet, student-friendly gigs, SOS</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-nearby-jobs-map.jpg" width="230" alt="Nearby gigs on a map"/><br/><sub><b>Nearby gigs</b><br/>live pins within 25 km, pay per day</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-digital-job-ticket.jpg" width="230" alt="Digital job ticket with a rotating QR"/><br/><sub><b>Digital job ticket</b><br/>QR pass that refreshes every few minutes</sub></td>
</tr>
</table>

**Farmers: list it, price it, sell it direct**

<table>
<tr>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-farmer-home.jpg" width="230" alt="Farmer home with weather advisory and mandi prices"/><br/><sub><b>Farmer home</b><br/>weather advisory and live mandi prices</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-produce-listings.jpg" width="230" alt="Produce listings"/><br/><sub><b>Produce listings</b><br/>price, stock, pause or edit in one tap</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-farmer-profile.jpg" width="230" alt="Farmer profile"/><br/><sub><b>Farm profile</b><br/>self-declared vs verified details stay clearly marked</sub></td>
</tr>
</table>

**Customers and trust: book, order, verify**

<table>
<tr>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-customer-home.jpg" width="230" alt="Customer hub"/><br/><sub><b>Customer hub</b><br/>verified local workers, one tap to book</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-farm-produce-market.jpg" width="230" alt="Farm produce marketplace"/><br/><sub><b>Farm produce</b><br/>order direct from nearby farms</sub></td>
<td align="center" width="33%"><img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/screenshots/us-worker-credentials.jpg" width="230" alt="Credentials, languages and skills"/><br/><sub><b>Credentials and skills</b><br/>licence, student, bank and background checks</sub></td>
</tr>
</table>

</div>

</details>

<details>
<summary><b>Watch the worker flow (GIF)</b></summary>

<br/>

<div align="center">
<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/media/us-app-tour.gif" width="260" alt="Screen recording of the worker home screen"/>
</div>

</details>

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## ✨ What it does

| | Module | Highlights |
|---|---|---|
| 🔐 | **Accounts and onboarding** | Phone OTP and Google sign-in via Supabase Auth, role selection, session restore, suspended-account handling |
| 💼 | **Job marketplace** | Post, discover, apply, accept, track status; duplicate applications rejected by the database |
| 🛠️ | **Local services** | Proximity search, booking requests, status tracking |
| 🌾 | **Farm-to-consumer market** | Produce listings with price and stock, cart, delivery or pickup, handover confirmation |
| 📍 | **Location matching** | GPS + PostGIS distance queries for jobs, workers and produce |
| 🛡️ | **Trust and attendance** | KYC, face verification, QR ticket, selfie and GPS check-in, work timer |
| 💳 | **Wallet and payments** | Razorpay in **sandbox** mode, orders created and verified server-side |
| ⭐ | **Ratings and disputes** | Only the two parties of a completed job can review; evidence upload; admin decision in an audit log |
| 🗣️ | **Voice assistant** | Speak to navigate, ask questions, get spoken answers |
| 🌦️ | **Agri information** | Mandi prices with source and date, weather advisories, cached fallback |
| 🔔 | **Notifications** | Push alerts that open a screen, which then reads the confirmed state from the backend |
| 🖥️ | **Admin portal** | Separate Java app for user review, listing moderation, payments, disputes and audit |

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🔁 How a job moves from post to paid

Every stage has **one acting role, one server-side check and one defined next state**, so a worker's view and a provider's view of a job never disagree.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-workflow.svg" width="100%" alt="Eight-stage job workflow"/>

> **Backend-confirmed state.** A stage changes only when the backend confirms the write, and the screen refreshes from that confirmed state. A success toast on a button is never treated as proof that data was stored, and a push notification only prompts the user to open a screen that reads the current status.

### Showing up: three proofs, one server decision

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-checkin.svg" width="100%" alt="QR, selfie and GPS check-in: attendance is accepted only when ticket, face and place all agree"/>

The same pattern, in a shorter form, drives produce orders: *listing → cart → order → fulfilment updates → handover → payment and reviews*, with the same dispute path if a handover goes wrong.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🎙️ Voice assistant

Speech is recognised on the device. The text goes through an authenticated Edge Function to a language model, and the answer is shown on screen and spoken back.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-voice.svg" width="100%" alt="Voice pipeline: speak, understand, decide, respond, confirm"/>

| Component | Role |
|---|---|
| Deepgram | Speech recognition and speech-related processing |
| Groq | Primary language-model provider |
| Google Gemini | Multimodal and more complex reasoning |
| OpenRouter | Fallback model provider |
| Hugging Face | Intent classification |
| Supabase Edge Function `ai-assist` | Authenticated entry point and orchestration: retries, circuit breakers, rate limiting, telemetry |

**Safety rules the assistant follows**

- It navigates only to an **allow-list of existing screens**.
- Every answer is **shown on screen**, not only spoken.
- A spoken request is **never treated as a stored change** until the server confirms it.
- Each failure (permission denied, unsupported language, no speech, network loss, provider error) returns the user to a usable screen.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🏗️ Architecture

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-architecture.svg" width="100%" alt="System architecture: one Supabase backend, two clients, keys that never leave the server"/>

Three principles hold the design together:

1. **The database is the single source of truth** for every status, so screens only show confirmed state.
2. **Authorisation is enforced by Row Level Security and server functions**, not by hiding buttons.
3. **No privileged credential is shared** between the mobile app and the admin app, which limits the damage if either client is compromised.

<details>
<summary><b>Full technology stack</b></summary>

<br/>

| Layer | Technology |
|---|---|
| Mobile app | Flutter, Dart, Riverpod, GoRouter |
| Voice and camera | speech_to_text, flutter_tts, audioplayers, camera, Google ML Kit face detection |
| QR and maps | mobile_scanner, qr_flutter, flutter_map, latlong2, geolocator, geocoding |
| Payments | razorpay_flutter (sandbox) |
| Local storage | flutter_secure_storage, shared_preferences |
| Notifications | firebase_messaging, local notifications |
| Backend | Supabase Auth, PostgreSQL + PostGIS, Row Level Security, Storage, Realtime |
| Server logic | Supabase Edge Functions (TypeScript on Deno) |
| AI and speech | Deepgram, Groq, Google Gemini, OpenRouter, Hugging Face |
| Map and agri data | OpenStreetMap-compatible tiles, Open-Meteo, Agmarknet and data.gov.in |
| Admin portal | Java 21, Spring Boot 3.3.5, Vaadin Flow 24.4.12, Spring Security, Maven |
| Android release | Gradle, R8/ProGuard, resource shrinking |

</details>

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🔒 Security hardening

A recent mobile security pass fixed eight findings:

| Area | Change |
|---|---|
| Biometric data | Face embeddings, cached photo bytes and stored face data are cleared on logout |
| Suspended accounts | Cached session state is cleared so an offline launch cannot bypass suspension |
| Android | Backup disabled; cleartext network traffic explicitly disabled |
| Logging | `debugPrint` silenced in release builds |
| Wallet input | Upper bound on add-money; withdrawal checked against balance before sending |
| Edge Function responses | `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` headers added |
| Dependencies | Packages updated, including a fix for a retracted `jni_flutter` release |
| Git hygiene | Lockfile handling corrected, ignore rules expanded, project-specific values removed from docs and examples |

<table>
<tr>
<td align="center"><b>0</b><br/><sub>analyzer issues</sub></td>
<td align="center"><b>551</b><br/><sub>files secret-scanned,<br/>0 secrets found</sub></td>
<td align="center"><b>22</b><br/><sub>security and widget<br/>tests passed</sub></td>
<td align="center"><b>33</b><br/><sub>layout-overflow tests<br/>passed</sub></td>
<td align="center"><b>7 × 1,364</b><br/><sub>localization files ×<br/>keys each</sub></td>
</tr>
</table>

> These figures come from the project's own audit report. Client-side wallet checks are a usability aid, **not** a security boundary: the backend validates limits, balances, permissions and payment status independently.

<details>
<summary><b>Still to confirm before a production release</b></summary>

<br/>

- [ ] Inspect Git **history** for committed credentials and rotate anything that was exposed
- [ ] Confirm RLS policies and backend authorisation hold without relying on the client
- [ ] Test phone OTP, Google sign-in and suspended-account behaviour on a real device
- [ ] Verify live payments, AI-provider authentication and push notifications in their target environments
- [ ] Build and sign the Android release, then test the release artifact

</details>

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 📊 Measured results

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-metrics.svg" width="100%" alt="Measured median and 95th percentile response time per core operation"/>

```mermaid
pie showData title Functional test cases (50)
    "Passing" : 47
    "Not passing" : 3
```

**What these numbers do and do not show.** Everything was measured on an Android device over Wi-Fi against a Supabase backend holding seeded data (30 users, 37 jobs, 19 produce listings), with sandbox payments. They describe system behaviour, not outcomes for workers or farmers. The study does not establish effects on income, booking rates or time to find work; that needs a field deployment.

### What integration buys you

| Capability | Job portals | Service-booking apps | Farm marketplaces | **UdyogaSethu** |
|---|:-:|:-:|:-:|:-:|
| Local job posting and application | ✅ | – | – | ✅ |
| Proximity-based service booking | – | ✅ | – | ✅ |
| Direct farm-produce listing and ordering | – | – | ✅ | ✅ |
| One account across both marketplaces | – | – | – | ✅ |
| QR + selfie + GPS attendance proof | – | partial | – | ✅ |
| Voice interaction in several Indian languages | varies | varies | varies | ✅ (8) |
| Evidence-based disputes with audit log | varies | varies | varies | ✅ |

The gain is **integration** (one identity, verification and payment flow for both marketplaces), not a new feature inside any single marketplace.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🚀 Getting started

> Adjust folder and variable names to match your repository layout.

**Prerequisites:** Flutter SDK, Android SDK, a Supabase project, JDK 21 and Maven (admin portal only), a Firebase project for push notifications.

```bash
# 1. Clone
git clone https://github.com/chethankp365/UdyogaSethu.git
cd UdyogaSethu

# 2. Mobile app
flutter pub get
# Add your own google-services.json (it is intentionally not committed)
# Point the app at your Supabase URL and anon key via your local config
flutter run
```

```bash
# 3. Edge Functions (AI orchestration, payments, face compare)
supabase functions deploy ai-assist
# Provider keys live in Supabase secrets, never in the app:
# supabase secrets set GROQ_API_KEY=... DEEPGRAM_API_KEY=...
```

```bash
# 4. Admin portal (separate project)
mvn spring-boot:run
```

**Configuration notes**

- Never commit service-role keys, provider keys or `google-services.json`.
- Production builds must run with `DEMO_BUILD=false`.
- Payments run against Razorpay **test mode**; no real money moves.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

## 🧭 Roadmap

- [ ] Field deployment with real workers, farmers, employers and customers
- [ ] Better job, service and produce recommendations
- [ ] More languages and better recognition across accents and noisy environments
- [ ] Offline access without weakening authentication
- [ ] Stronger liveness checks against spoofing in face verification
- [ ] Large-scale, realistic load testing
- [ ] Full production payment lifecycle beyond sandbox
- [ ] Review alignment with state gig-worker welfare laws (statutory schemes are **not** implemented today)

## ⚠️ Honest limitations

- All measurements use seeded data, sandbox payments and a small test environment.
- DigiLocker/eKYC integration is part of the concept; do not treat it as a live, production-verified connection.
- Having a voice assistant does not by itself prove accuracy in every language; the 87.5% overall intent accuracy comes from 160 test utterances.
- Demonstration screens show seeded data, not real transactions.

## 👤 Author

**Chethan Kumar KP**
Department of Computer Science and Design, Atria Institute of Technology, Bengaluru

**Project guide:** Poornima T, Assistant Professor

### Cite this work

> C. Kumar KP, "UdyogaSethu: A Smart Digital Ecosystem for Informal Workforce Empowerment and Agricultural Market Integration," Atria Institute of Technology, Bengaluru, India. Guide: P. T.

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/svg/us-divider.svg" width="100%" alt=""/>

<div align="center">

**Work. Farm. Voice. Trust.**
*Bridging people to opportunity, one conversation at a time.*

<sub>Licence: add your chosen licence here · Please never publish private credentials or service-role keys.</sub>

<br/><br/>

<img src="https://raw.githubusercontent.com/chethankp365/UdyogaSethu/main/assets/us-logo.png" alt="UdyogaSethu logo" width="260"/>

</div>
